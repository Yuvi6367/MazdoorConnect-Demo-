package com.example.test02;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import com.example.test02.R;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Force fullscreen (hide status and navigation bars)
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | // Hide the status bar
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | // Hide the navigation bar
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY // Prevent system bars from reappearing
        );

        // Ensure no title bar
        getSupportActionBar().hide(); // Hides the ActionBar

        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.WebView);
        webView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Load the main HTML file
        webView.loadUrl("file:///android_asset/index.html");
    }
}